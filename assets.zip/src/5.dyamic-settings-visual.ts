/*
*  Power BI Visual CLI
*
*  Copyright (c) Microsoft Corporation
*  All rights reserved.
*  MIT License
*
*  Permission is hereby granted, free of charge, to any person obtaining a copy
*  of this software and associated documentation files (the ""Software""), to deal
*  in the Software without restriction, including without limitation the rights
*  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
*  copies of the Software, and to permit persons to whom the Software is
*  furnished to do so, subject to the following conditions:
*
*  The above copyright notice and this permission notice shall be included in
*  all copies or substantial portions of the Software.
*
*  THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
*  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
*  THE SOFTWARE.
*/
"use strict";

import "core-js/stable";
import "./../style/visual.less";
import powerbi from "powerbi-visuals-api";

import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisual = powerbi.extensibility.visual.IVisual;
import EnumerateVisualObjectInstancesOptions = powerbi.EnumerateVisualObjectInstancesOptions;
import VisualObjectInstance = powerbi.VisualObjectInstance;
import DataView = powerbi.DataView;
import VisualObjectInstanceEnumerationObject = powerbi.VisualObjectInstanceEnumerationObject;
import VisualObjectInstanceEnumeration = powerbi.VisualObjectInstanceEnumeration;
import IVisualHost = powerbi.extensibility.visual.IVisualHost
import { select, Selection, axisBottom, scaleBand, scaleLinear, max } from "d3";


import { VisualSettings } from "./settings";

export class Visual implements IVisual {

    private svg: Selection<SVGElement, any, any, any>;
    private barContainer: Selection<SVGElement, any, any, any>;
    private textContainer: Selection<SVGElement, any, any, any>;
    private axis;

    private host: IVisualHost;
    private settings: VisualSettings;


    constructor(options: VisualConstructorOptions) {

        this.svg = select(options.element).append("svg");
        this.barContainer = this.svg.append("g");
        this.textContainer = this.svg.append("g");

        this.host = options.host;
        this.axis = this.svg.append("g");

    }


    public update(options: VisualUpdateOptions) {
        //Parse settins objects
        this.settings = Visual.parseSettings(options && options.dataViews && options.dataViews[0]);
        console.log("visualSettings", options.dataViews, this.settings);
        const width = options.viewport.width;
        const height = options.viewport.height;

        // Get dynamic data
        const extractData = [];
        if (options.dataViews && options.dataViews[0].categorical && options.dataViews[0].categorical.categories && options.dataViews[0].categorical.values) {
            const categoricalData = options.dataViews[0].categorical;
            console.log("categoricalData", categoricalData);
            const category = categoricalData.categories[0];
            const valueData = categoricalData.values[0];
            for (let i = 0; i < category.values.length; i++) {
                extractData.push({
                    category: category.values[i],
                    value: valueData.values[i],
                    color: this.settings.dataPoint.defaultColor ? this.settings.dataPoint.defaultColor : this.host.colorPalette.getColor(category.values[i] as string).value
                });
            }
        }

        console.log("extractData", extractData);

        const x = scaleBand()
            .domain(extractData.map(dataPoint => dataPoint.category))
            .rangeRound([0, width])
            .padding(0.1);

        const y = scaleLinear()
            .domain([0, max(extractData, dataPoint => dataPoint.value)])
            .range([height - 20, 0]);
        // X axis
        const xAxis = axisBottom(x);
        this.axis.call(xAxis).attr('transform', `translate(0, ${height - 20})`)
            .style("font-size", `${this.settings.dataPoint.fontSize}px`);

        this.svg.attr("width", width)
            .attr("height", height);

        const bar = this.barContainer
            .selectAll(".bar")
            .data(extractData);

        bar.enter()
            .append("rect")
            .classed("bar", true)
            .attr("width", x.bandwidth())
            .attr("height", dataPoint => height - y(dataPoint.value) - 50)
            .attr("fill", dataPoint => dataPoint.color)
            .attr("x", dataPoint => x(dataPoint.category) + 10)
            .attr("y", dataPoint => y(dataPoint.value) + 30);

        // Resizing the bar
        bar.attr("width", x.bandwidth())
            .attr("height", dataPoint => height - y(dataPoint.value) - 50)
            .attr("fill", dataPoint => dataPoint.color)
            .attr("x", dataPoint => x(dataPoint.category) + 10)
            .attr("y", dataPoint => y(dataPoint.value) + 30);

        // Add a text label for values
        const text = this.textContainer
            .selectAll(".number-label")
            .data(extractData);


        // show/hide the label dynamically        
        if (this.settings.dataPoint.showAllDataPoints) {
            console.log("True");
            text.enter()
                .append("text")
                .classed("number-label", true)
                .attr("x", dataPoint => x(dataPoint.category) + x.bandwidth() / 2 - 15)
                .attr("y", dataPoint => y(dataPoint.value) + 20)
                .style("font-size", `${this.settings.dataPoint.fontSize}px`)
                .text(function (d) { return d.value.toFixed(0); });

            // Resizing the text label while resizing
            text.attr("x", dataPoint => x(dataPoint.category) + x.bandwidth() / 2 - 15)
                .attr("y", dataPoint => y(dataPoint.value) + 20)
                .style("font-size", `${this.settings.dataPoint.fontSize}px`)
                .text(function (d) { return d.value.toFixed(0); });
        }else{
            this.textContainer
            .selectAll(".number-label").remove();
        }

        // Remove the bar if data is not exist
        bar.exit().remove();
        text.exit().remove();

    }


    private static parseSettings(dataView: DataView): VisualSettings {
        return <VisualSettings>VisualSettings.parse(dataView);
    }

    /**
     * This function gets called for each of the objects defined in the capabilities files and allows you to select which of the
     * objects and properties you want to expose to the users in the property pane.
     *
     */
    public enumerateObjectInstances(options: EnumerateVisualObjectInstancesOptions): VisualObjectInstance[] | VisualObjectInstanceEnumerationObject {
        return VisualSettings.enumerateObjectInstances(this.settings || VisualSettings.getDefault(), options);
    }
}