/*
*  Power BI Visual CLI
*
*  Copyright (c) Microsoft Corporation
*  All rights reserved.
*  MIT License
*
*  Permission is hereby granted, free of charge, to any person obtaining a copy
*  of this software and associated documentation files (the ""Software""), to deal
*  in the Software without restriction, including without limitation the rights
*  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
*  copies of the Software, and to permit persons to whom the Software is
*  furnished to do so, subject to the following conditions:
*
*  The above copyright notice and this permission notice shall be included in
*  all copies or substantial portions of the Software.
*
*  THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
*  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
*  THE SOFTWARE.
*/
"use strict";

import "core-js/stable";
import "./../style/visual.less";
import powerbi from "powerbi-visuals-api";
import { select, Selection, scaleBand, AxisDomain, scaleLinear, max } from "d3";
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisual = powerbi.extensibility.visual.IVisual;
import DataView = powerbi.DataView;

export class Visual implements IVisual {

    private svg: Selection<SVGElement, any, any, any>;
    private barContainer: Selection<SVGElement, any, any, any>;

    constructor(options: VisualConstructorOptions) {

        this.svg = select(options.element).append("svg");
        this.barContainer = this.svg.append("g");

    }

    public update(options: VisualUpdateOptions) {

        const width = options.viewport.width;
        const height = options.viewport.height;

        // Get dynamic data

        const extractData = [];
        if (options.dataViews && options.dataViews[0].categorical && options.dataViews[0].categorical.categories && options.dataViews[0].categorical.values) {
            const categoricalData = options.dataViews[0].categorical;
            console.log("categoricalData", categoricalData);
            const category = categoricalData.categories[0];
            const valueData = categoricalData.values[0];
            for (let i = 0; i < category.values.length; i++) {
                extractData.push({
                    category: category.values[i],
                    value: valueData.values[i]
                });
            }
        }

        console.log("extractData", extractData);

        const x = scaleBand()
            .domain(extractData.map(dataPoint => dataPoint.category))
            .rangeRound([0, width])
            .padding(0.1);

        const y = scaleLinear()
            .domain([0, max(extractData, dataPoint => dataPoint.value)])
            .range([height, 0]);

        this.svg.attr("width", width)
            .attr("height", height);

        const bar = this.barContainer
            .selectAll(".bar")
            .data(extractData);

        bar.enter()
            .append("rect")
            .classed("bar", true)
            .attr("width", x.bandwidth())
            .attr("height", dataPoint => height - y(dataPoint.value))
            .attr("fill", "red")
            .attr("x", dataPoint => x(dataPoint.category))
            .attr("y", dataPoint => y(dataPoint.value));

        // Resizing the bar
        bar.attr("width", x.bandwidth())
            .attr("height", dataPoint => height - y(dataPoint.value))
            .attr("fill", "red")
            .attr("x", dataPoint => x(dataPoint.category))
            .attr("y", dataPoint => y(dataPoint.value));

        // Remove the bar if data is not exist
        bar.exit().remove();
    }

}